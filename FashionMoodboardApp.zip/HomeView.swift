import SwiftUI

struct HomeView: View {
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading) {
                    Text("Going out outfits")
                        .font(.title2)
                        .bold()
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3)) {
                        ForEach(1..<4) { index in
                            MoodboardThumbnail(title: "Outfit \(index)")
                        }
                    }

                    Text("Office Fashion")
                        .font(.title2)
                        .bold()
                        .padding(.top)
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3)) {
                        ForEach(1..<5) { index in
                            MoodboardThumbnail(title: "Outfit \(index)")
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("my moodboard")
        }
    }
}

struct MoodboardThumbnail: View {
    let title: String
    var body: some View {
        RoundedRectangle(cornerRadius: 12)
            .fill(Color(.systemYellow).opacity(0.2))
            .frame(height: 100)
            .overlay(Text(title).foregroundColor(.brown))
    }
}