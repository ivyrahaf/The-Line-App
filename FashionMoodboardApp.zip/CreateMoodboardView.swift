import SwiftUI
import PhotosUI

struct CreateMoodboardView: View {
    @State private var selectedItems: [UIImage] = []
    @State private var showPhotoPicker = false
    @State private var showCamera = false
    @State private var imageToAdd: UIImage?

    var body: some View {
        VStack {
            HStack {
                Image(systemName: "square.and.pencil")
                Text("create moodboard")
                    .font(.title2)
                    .bold()
                Spacer()
                Button(action: { showCamera = true }) {
                    Image(systemName: "camera")
                }
            }
            .padding()

            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color(.systemYellow).opacity(0.2))
                    .frame(height: 250)

                ForEach(selectedItems.indices, id: \.self) { i in
                    Image(uiImage: selectedItems[i])
                        .resizable()
                        .frame(width: 80, height: 80)
                        .position(x: CGFloat(100 + (i * 40)), y: 100)
                }
            }

            Text("choose items")
                .font(.title3)
                .bold()
                .padding(.top)

            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3)) {
                ForEach(["item1", "item2", "item3", "item4", "item5", "item6"], id: \ .self) { item in
                    Image(item)
                        .resizable()
                        .frame(width: 80, height: 80)
                        .onTapGesture {
                            if let img = UIImage(named: item) {
                                selectedItems.append(img)
                            }
                        }
                }
            }

            Button(action: {
                showPhotoPicker = true
            }) {
                Image(systemName: "camera")
                    .padding()
            }
        }
        .photosPicker(isPresented: $showPhotoPicker, selection: .constant(nil))
        .sheet(isPresented: $showCamera) {
            Text("Camera goes here") // placeholder for real integration
        }
    }
}