import SwiftUI

@main
struct FashionMoodboardApp: App {
    var body: some Scene {
        WindowGroup {
            DashboardView()
        }
    }
}