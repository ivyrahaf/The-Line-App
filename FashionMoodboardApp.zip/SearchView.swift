import SwiftUI

struct SearchView: View {
    var body: some View {
        VStack {
            Text("Search feature coming soon!")
                .foregroundColor(.gray)
        }
        .padding()
    }
}