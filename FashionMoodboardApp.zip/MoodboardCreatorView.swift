
import SwiftUI

struct MoodboardCreatorView: View {
    @State private var showImagePicker = false
    @State private var selectedImage: UIImage?
    @State private var sourceType: UIImagePickerController.SourceType = .photoLibrary

    var body: some View {
        VStack(spacing: 20) {
            HStack {
                Text("create moodboard")
                    .font(.title2.bold())
                    .foregroundColor(.brown)
                Spacer()
                Button {
                    sourceType = .camera
                    showImagePicker = true
                } label: {
                    Image(systemName: "camera")
                        .font(.title2)
                        .foregroundColor(.brown)
                }
            }
            .padding(.horizontal)

            ZStack {
                Rectangle()
                    .fill(Color(.systemGray6))
                    .frame(height: 300)
                    .cornerRadius(12)

                if let image = selectedImage {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(height: 280)
                } else {
                    Text("Add items or take a photo")
                        .foregroundColor(.gray)
                }
            }
            .padding(.horizontal)

            Text("choose items")
                .font(.headline)
                .foregroundColor(.brown)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal)

            Spacer()
        }
        .sheet(isPresented: $showImagePicker) {
            ImagePicker(sourceType: sourceType, selectedImage: $selectedImage)
        }
    }
}
